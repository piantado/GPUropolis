 
GPUropolis is software for using CUDA to run MCMC on compositional spaces. At present it runs symbolic regression on a variety of historical data sets. 

GPUropolis is under heavy development by colala, the computation and language lab at the University of Rochester. Constact Steve Piantadosi (spiantadosi@bcs.rochester.edu) for questions. 

