import matplotlib
import matplotlib.pyplot as plt
import argparse

from Shared import *

parser = argparse.ArgumentParser(description='MCMC for Baboon data!')
parser.add_argument('--in', dest='in', type=str, default='o.txt', nargs="?", help='The input sample file')
parser.add_argument('--data', dest='data', type=str, default='data.txt', nargs="?", help='The input data file')
parser.add_argument('--out', dest='out', type=str, default='o.pdf', nargs="?", help='The output plot')
args = vars(parser.parse_args())

NCURVEPTS = 1000 # How many curve points to plot?

## --------------------------------------
## Read the data file
## --------------------------------------

xs, ys = [], []
for l in open(args['data'], 'r'):
	l = l.strip()
	if re.match("\s*#",l): continue
	
	x,y = map(float, re.split("\t", l))
	
	xs.append(x)
	ys.append(y)
xs = numpy.array(xs)
ys = numpy.array(ys)

newx = numpy.arange(min(xs), max(xs), (max(xs)-min(xs))/float(NCURVEPTS))

## --------------------------------------
## Read the hypotheses
## --------------------------------------

H = []
Hlp = []
for l in open(args['in'], 'r'):
	if re.match("\s*#",l): continue
	l = l.strip()
	parts = re.split("\t", l)
	
	sn, n, lp, h = parts[0], parts[1], parts[2], parts[-1]
	sn = int(sn)
	n = int(n)
	h = re.sub("\"", "", h) # remove quotes
	lp = float(lp)
	
	H.append( h )
	Hlp.append(lp)
	
Hlp = numpy.array(Hlp)
Z = logsumexp(Hlp)

## --------------------------------------
## Make the plots
## --------------------------------------

fig = matplotlib.pyplot.figure(figsize=(5,4))
plt = fig.add_subplot(1,1,1)

for i in xrange(len(H)):
	h = H[i]
	p = exp(Hlp[i]-Z)
	
	if p < 1e-6: continue
	p = p / exp(max(Hlp-Z))
	
	f = eval('lambda x: '+h)
	
	print p, Hlp[i], Hlp[i]-Z, h
	newy = failmap(f, newx)
	
	try: plt.plot(newx, newy, alpha=p, color="gray")
	except OverflowError: pass


# Plot the data
try: plt.scatter(xs,ys)
except OverflowError: pass

plt.set_xlim(min(xs), max(xs))
plt.set_ylim(-max(abs(ys)), max(abs(ys)))
fig.savefig(args['out'])

# Done

