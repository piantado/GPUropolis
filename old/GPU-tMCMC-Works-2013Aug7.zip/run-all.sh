

ITERATIONS=5000
OUTER=1
N=1300

EXEC=./gpumcmc

# for WHICHHALF in '' --first-half; do
# for DATA in CLT Boyle Null COBE PrimeCounting Zipf Constant Hubble Galileo BraheMars; do
# for DATA in Hubble BraheMars ; do
for DATA in PrimeCounting ; do

	LOG=run2/$DATA/log.txt
	OUT=run2/$DATA/
	
	mkdir $OUT
	mkdir $OUT/used-data/
# 	cp -r data-sources/$DATA/* $OUT/used-data/
# 	
# 	#echo to a log file
# 	echo Run started on $(date)           >> $LOG
# 	echo by $(whoami) on $(hostname)      >> $LOG
# 	echo Executable MD5: $(md5sum $EXEC)  >> $LOG
# 	echo                                  >> $LOG      
# 	echo ----------------------------     >> $LOG      
# 	echo -- PARAMETERS:                   >> $LOG
# 	echo ----------------------------     >> $LOG      
# 	echo ITERATIONS=$ITERATIONS           >> $LOG
# 	echo OUTER=$OUTER                     >> $LOG
# 	echo N=$N                             >> $LOG
# 	echo                                  >> $LOG      
	
	# run the CUDA MCMC; must use gnu time in order to output
	/usr/bin/time --output=$OUT/time.txt $EXEC --iterations=$ITERATIONS --in=data-sources/$DATA/data.txt --outer=$OUTER --N=$N > $OUT/raw_samples.txt
	echo CUDA mcmc completed on $(date) >> $LOG
	
	# And a python post-processing script
# 	nice -n 19 python plot.py --in=$OUT/raw_samples.txt --data=data-sources/$DATA/data.txt --out=$OUT &
	echo Python completed on $(date) >> $LOG	

# done
done
